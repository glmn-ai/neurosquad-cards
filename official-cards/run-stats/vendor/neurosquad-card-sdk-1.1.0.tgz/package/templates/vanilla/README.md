# __CARD_DISPLAY_NAME__

A custom card for [NeuroSquad](https://neurosquad.ai), made with `@neurosquad/card-sdk`
(vanilla template — no build step).

## Files

| File | What it is |
| --- | --- |
| `neurosquad-card.json` | The manifest: name, size, permissions, settings, ports, tools |
| `index.html`, `main.js`, `style.css` | The card itself — a small web page |
| `icon.png` | Square PNG/WebP, ≤ 128 KB |
| `vendor/` | The SDK (`card-sdk.js`), the optional UI kit (`ui.css`), the mock host for previews and the manifest schema |

## Develop

1. In NeuroSquad: **Settings → Custom cards → Developer mode**.
2. In this folder: `npx @neurosquad/card-sdk dev` — confirm the link in the app,
   then add the card from the canvas (**+ → Custom card…**). Saving a file reloads it;
   the card's log prints in your terminal.

Preview in a browser without the app: `npx serve .` and open the page — it runs
against a mock host with sample agents.

## Check and share

```sh
npx @neurosquad/card-sdk validate   # the app's own checks + the install dialog preview
npx @neurosquad/card-sdk pack       # what would be installed, and the tree hash
```

Push this folder to GitHub. People install it by pasting `owner/repo` (or
`owner/repo/path/to/folder`) into **Settings → Custom cards**.

Card code runs in a sandbox: no inline scripts, no external resources (bundle
everything into the folder), network only through `card.net.fetch` to hosts you
declare in the `network` permission.
