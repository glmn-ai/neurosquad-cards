# __CARD_DISPLAY_NAME__

A custom card for [NeuroSquad](https://neurosquad.ai), made with `@neurosquad/card-sdk`
(React + Vite template).

## Develop

```sh
npm install
npm run dev        # preview in the browser against a mock host with sample agents
```

Live in the app:

1. In NeuroSquad: **Settings → Custom cards → Developer mode**.
2. `npx neurosquad-card dev` — it runs `npm run watch` (rebuilds `dist/` on save),
   links this folder into the app (confirm there) and prints the card's log.
   Add the card from the canvas: **+ → Custom card…**.

## Check and share

```sh
npm run build      # dist/ — the app loads dist/index.html (see "entry" in the manifest)
npm run validate   # the app's own checks + the install dialog preview
npm run pack       # what would be installed, and the tree hash
```

**Commit `dist/`.** NeuroSquad installs straight from the GitHub repository and
does not run your build. People install the card by pasting `owner/repo` (or
`owner/repo/path/to/folder`) into **Settings → Custom cards**.

Card code runs in a sandbox: no inline scripts, no external resources (Vite
bundles everything), network only through `card.net.fetch` to hosts declared in
the `network` permission.
