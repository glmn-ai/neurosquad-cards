import {
  permissionForPeer,
  requestPermissions,
  type AgentStatus,
  type PermissionId
} from '@neurosquad/card-sdk'
import {
  useAgents,
  useCard,
  useCardContext,
  useEmit,
  usePort,
  useSettings,
  useStorage,
  useTool,
  useTranslator
} from '@neurosquad/card-sdk/react'
import { useEffect, useState } from 'react'
import { catalog } from './i18n'

const TONE: Record<AgentStatus, string> = {
  working: 'ns-dot--accent',
  'needs-input': 'ns-dot--warning',
  finished: 'ns-dot--success',
  idle: '',
  exited: 'ns-dot--danger'
}

export function App(): React.JSX.Element {
  const card = useCard()
  const { workspace, instance } = useCardContext()
  const [settings] = useSettings()
  const t = useTranslator(catalog)
  const { agents } = useAgents()
  const [pad, setPad] = useStorage('scratchpad', '')
  const [hint, setHint] = useState('')
  const emitScratchpad = useEmit<string>('scratchpad')

  const working = agents.filter((agent) => agent.status === 'working').length

  // What the overview tile shows when the canvas is zoomed out.
  useEffect(() => {
    void card.setOverview({
      primary: t('working', { count: working }),
      tone: working ? 'accent' : 'default',
      icon: 'users'
    })
  }, [card, t, working])

  // Text arriving on the "text" input port is appended to the scratchpad.
  const { message } = usePort<string>('text')
  useEffect(() => {
    if (message)
      setPad((previous) =>
        previous ? `${previous}\n${message.data as string}` : (message.data as string)
      )
  }, [message, setPad])

  // A tool for connected agents: they can read what the user wrote here.
  useTool('read_scratchpad', () => pad || '(the scratchpad is empty)')

  const send = async (): Promise<void> => {
    try {
      // A note's input needs the optional cards.connected permission: ask for
      // it (the app shows its own prompt) before the first send.
      const needed = card.ports.peers
        .filter((peer) => peer.direction !== 'upstream')
        .map((peer) => permissionForPeer(peer, { outputType: 'ns:markdown' }))
        .filter((id): id is PermissionId => id !== null)
      if (needed.length > 0) await requestPermissions(card, ...new Set(needed))
      const delivered = await emitScratchpad(pad)
      setHint(delivered > 0 ? t('sent', { count: delivered }) : t('notConnected'))
    } catch (error) {
      setHint(error instanceof Error ? error.message : String(error))
    }
  }

  return (
    <main className="app">
      <header className="ns-spread">
        <div className="ns-grow">
          <p className="ns-subtitle ns-truncate">{workspace.name}</p>
          <h1 className="ns-title ns-truncate">
            {String(settings.values['greeting'] ?? instance.displayName)}
          </h1>
        </div>
        <span className="ns-badge ns-badge--accent" title={t('working', { count: working })}>
          {working}
        </span>
      </header>

      <section className="ns-surface ns-surface--inset agents">
        <p className="ns-subtitle">{t('agents')}</p>
        <ul className="ns-list ns-scroll">
          {agents.length === 0 && <li className="ns-list-item ns-muted">{t('noAgents')}</li>}
          {agents.map((agent) => (
            <li key={agent.id} className="ns-list-item">
              <span className={`ns-dot ${TONE[agent.status]}`} />
              <span className="ns-truncate">{agent.name}</span>
              <span className="agent-status ns-muted">{t(`status.${agent.status}`)}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="ns-field pad">
        <label className="ns-label" htmlFor="pad">
          {t('scratchpad')}
        </label>
        <textarea
          id="pad"
          className="ns-textarea"
          spellCheck={false}
          value={pad}
          onChange={(event) => setPad(event.target.value)}
        />
      </section>

      <footer className="ns-spread">
        <span className="ns-small ns-muted ns-truncate">{hint}</span>
        <button
          className="ns-btn ns-btn--primary ns-btn--sm"
          type="button"
          onClick={() => void send()}
        >
          {t('send')}
        </button>
      </footer>
    </main>
  )
}
