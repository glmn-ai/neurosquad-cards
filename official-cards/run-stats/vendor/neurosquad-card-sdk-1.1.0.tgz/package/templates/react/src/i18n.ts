import type { Catalog } from '@neurosquad/card-sdk'

/** The card's own strings in the app's three languages (en is the fallback). */
export const catalog: Catalog = {
  en: {
    agents: 'Agents',
    scratchpad: 'Scratchpad',
    send: 'Send',
    noAgents: 'No agents on this canvas yet',
    working_one: '{{count}} agent working',
    working_other: '{{count}} agents working',
    sent_one: 'Sent to {{count}} card',
    sent_other: 'Sent to {{count}} cards',
    notConnected: 'Draw an arrow from this card to a note to send it there',
    status: {
      working: 'working',
      'needs-input': 'waiting for you',
      finished: 'finished',
      idle: 'idle',
      exited: 'stopped'
    }
  },
  ru: {
    agents: 'Агенты',
    scratchpad: 'Черновик',
    send: 'Отправить',
    noAgents: 'На холсте пока нет агентов',
    working_one: 'Работает {{count}} агент',
    working_few: 'Работают {{count}} агента',
    working_many: 'Работают {{count}} агентов',
    working_other: 'Работают {{count}} агента',
    sent_one: 'Отправлено в {{count}} карточку',
    sent_few: 'Отправлено в {{count}} карточки',
    sent_many: 'Отправлено в {{count}} карточек',
    sent_other: 'Отправлено в {{count}} карточки',
    notConnected: 'Проведите стрелку от этой карточки к заметке, чтобы отправить туда',
    status: {
      working: 'работает',
      'needs-input': 'ждёт вас',
      finished: 'закончил',
      idle: 'свободен',
      exited: 'остановлен'
    }
  },
  zh: {
    agents: '智能体',
    scratchpad: '草稿',
    send: '发送',
    noAgents: '画布上还没有智能体',
    working_other: '{{count}} 个智能体正在工作',
    sent_other: '已发送到 {{count}} 张卡片',
    notConnected: '从此卡片画一条箭头到笔记，即可发送到那里',
    status: {
      working: '工作中',
      'needs-input': '等待你',
      finished: '已完成',
      idle: '空闲',
      exited: '已停止'
    }
  }
}
