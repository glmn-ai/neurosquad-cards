// Import the SDK first, from the entry module: it starts listening for the
// app's handshake as soon as it loads.
import { connect, type Card, type CardManifest } from '@neurosquad/card-sdk'
import { CardProvider } from '@neurosquad/card-sdk/react'
import '@neurosquad/card-sdk/ui.css'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import manifest from '../neurosquad-card.json'
import { App } from './App'
import './styles.css'

/** Opened on its own (`npm run dev`), the card runs against a mock host with sample data. */
async function previewCard(): Promise<Card> {
  const { createMockHost } = await import('@neurosquad/card-sdk/testing')
  const host = createMockHost({
    manifest: manifest as unknown as CardManifest,
    agents: [
      {
        id: 'a1',
        name: 'Claude Code',
        harness: 'claude-code',
        kind: 'ai',
        status: 'working',
        connected: true
      },
      {
        id: 'a2',
        name: 'Codex',
        harness: 'codex-cli',
        kind: 'ai',
        status: 'needs-input',
        connected: false
      },
      {
        id: 't1',
        name: 'PowerShell',
        harness: 'shell-powershell',
        kind: 'shell',
        status: 'idle',
        connected: false
      }
    ],
    peers: [
      {
        cardId: 'note-1',
        kind: 'note',
        name: 'Notes',
        direction: 'downstream',
        inputs: [
          {
            id: 'append',
            label: 'Append',
            type: 'ns:markdown',
            mode: 'stream',
            retain: false,
            default: true,
            // Like the app: sending to a note needs cards.connected.
            permission: 'cards.connected'
          }
        ],
        outputs: []
      }
    ]
  })
  Object.assign(window, { mockHost: host }) // try mockHost.setAgentStatus('a2', 'working') in DevTools
  return host.connect()
}

const card = window.parent === window ? await previewCard() : await connect()

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <CardProvider card={card}>
      <App />
    </CardProvider>
  </StrictMode>
)
