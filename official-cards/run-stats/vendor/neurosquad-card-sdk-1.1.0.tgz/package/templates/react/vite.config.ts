import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// The app serves the built card from nscard://<id>/dist/…, so every URL must be
// relative (base './'). Commit dist/: installs come straight from the repository.
export default defineConfig({
  base: './',
  plugins: [react()],
  // One React even when the SDK is linked from a local checkout (file: deps are
  // symlinks, and Vite would resolve react next to the SDK's real path).
  resolve: { dedupe: ['react', 'react-dom'] },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    // The card CSP allows scripts only from the package; no inline preload polyfill.
    modulePreload: { polyfill: false },
    target: 'es2022'
  }
})
